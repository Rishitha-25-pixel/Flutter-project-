# Flutter Chat App

## Setup

1. Install Flutter and create/open this project.
2. Run `flutter pub get`.
3. Create a Firebase project.
4. Enable Email/Password Authentication.
5. Create a Firestore database.
6. Add your Android/iOS Firebase configuration.
7. Deploy the included Firestore rules.
8. Run `flutter run`.

## Firebase configuration

For Android, add `google-services.json` under `android/app/`.
For iOS, add `GoogleService-Info.plist` to the Runner target.

Alternatively, use FlutterFire CLI:

`dart pub global activate flutterfire_cli`

`flutterfire configure`

This generates `lib/firebase_options.dart`; then initialize Firebase with
`DefaultFirebaseOptions.currentPlatform` in `main.dart`.

## Firestore structure

users/{uid}
chatRooms/{roomId}
chatRooms/{roomId}/messages/{messageId}

The current implementation supports authentication, private chats,
real-time text messages, read state fields, group-ready room fields,
and the basic service/provider architecture.
