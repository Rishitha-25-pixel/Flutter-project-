import 'package:cloud_firestore/cloud_firestore.dart';

class ChatRoom {
  final String id;
  final List<String> members;
  final String? lastMessage;
  final DateTime? lastMessageTime;
  final String? groupName;
  final bool isGroup;

  ChatRoom({
    required this.id,
    required this.members,
    this.lastMessage,
    this.lastMessageTime,
    this.groupName,
    this.isGroup = false,
  });

  factory ChatRoom.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    final ts = data['lastMessageTime'];
    return ChatRoom(
      id: doc.id,
      members: List<String>.from(data['members'] ?? []),
      lastMessage: data['lastMessage'],
      lastMessageTime: ts is Timestamp ? ts.toDate() : null,
      groupName: data['groupName'],
      isGroup: data['isGroup'] ?? false,
    );
  }
}
