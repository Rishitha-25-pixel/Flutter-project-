import 'package:flutter/material.dart';

class ChatTile extends StatelessWidget {
  final String title;
  final String subtitle;
  final VoidCallback? onTap;
  const ChatTile({super.key, required this.title, required this.subtitle, this.onTap});

  @override
  Widget build(BuildContext context) => ListTile(
    leading: const CircleAvatar(child: Icon(Icons.person)),
    title: Text(title),
    subtitle: Text(subtitle),
    onTap: onTap,
  );
}
