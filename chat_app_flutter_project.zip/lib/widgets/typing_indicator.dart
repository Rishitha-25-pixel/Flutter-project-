import 'package:flutter/material.dart';

class TypingIndicator extends StatelessWidget {
  final bool visible;
  const TypingIndicator({super.key, this.visible = true});

  @override
  Widget build(BuildContext context) =>
      visible ? const Padding(padding: EdgeInsets.all(8), child: Text('typing...')) : const SizedBox.shrink();
}
