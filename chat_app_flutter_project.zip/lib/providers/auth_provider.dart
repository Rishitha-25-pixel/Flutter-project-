import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import '../services/auth_service.dart';

class AuthProvider extends ChangeNotifier {
  final AuthService _service = AuthService();

  Stream<User?> get authStateChanges => _service.authStateChanges;
  User? get currentUser => FirebaseAuth.instance.currentUser;

  Future<void> login(String email, String password) =>
      _service.login(email, password).then((_) => notifyListeners());

  Future<void> signUp(String name, String email, String password) =>
      _service.signUp(name, email, password).then((_) => notifyListeners());

  Future<void> logout() => _service.logout().then((_) => notifyListeners());
}
