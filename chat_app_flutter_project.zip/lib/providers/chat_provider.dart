import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import '../services/chat_service.dart';

class ChatProvider extends ChangeNotifier {
  final ChatService service = ChatService();

  Stream<QuerySnapshot> rooms(String uid) => service.rooms(uid);
  Stream<QuerySnapshot> messages(String roomId) => service.messages(roomId);
  Stream<QuerySnapshot> users() => service.users();

  Future<String> createRoom(String uid, String otherUid) =>
      service.createPrivateRoom(uid, otherUid);

  Future<void> send({
    required String roomId,
    required String senderId,
    required String senderName,
    required String text,
    String? imageUrl,
  }) => service.sendMessage(
    roomId: roomId,
    senderId: senderId,
    senderName: senderName,
    text: text,
    imageUrl: imageUrl,
  );
}
