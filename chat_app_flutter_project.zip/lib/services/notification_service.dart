class NotificationService {
  // Add Firebase Cloud Messaging here when push notifications are required.
  Future<void> initialize() async {}
}
