import 'package:cloud_firestore/cloud_firestore.dart';

class ChatService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  Stream<QuerySnapshot> rooms(String uid) {
    return _db.collection('chatRooms')
        .where('members', arrayContains: uid)
        .orderBy('lastMessageTime', descending: true)
        .snapshots();
  }

  Stream<QuerySnapshot> messages(String roomId) {
    return _db.collection('chatRooms').doc(roomId)
        .collection('messages')
        .orderBy('timestamp')
        .snapshots();
  }

  Stream<QuerySnapshot> users() => _db.collection('users').snapshots();

  Future<String> createPrivateRoom(String uid, String otherUid) async {
    final ids = [uid, otherUid]..sort();
    final roomId = ids.join('_');
    await _db.collection('chatRooms').doc(roomId).set({
      'members': ids,
      'isGroup': false,
      'lastMessage': '',
      'lastMessageTime': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
    return roomId;
  }

  Future<void> sendMessage({
    required String roomId,
    required String senderId,
    required String senderName,
    required String text,
    String? imageUrl,
  }) async {
    final room = _db.collection('chatRooms').doc(roomId);
    await room.collection('messages').add({
      'senderId': senderId,
      'senderName': senderName,
      'text': text,
      'imageUrl': imageUrl,
      'timestamp': FieldValue.serverTimestamp(),
      'isRead': false,
    });
    await room.set({
      'lastMessage': text.isEmpty ? '📷 Image' : text,
      'lastMessageTime': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  Future<void> markMessagesRead(String roomId, String uid) async {
    final snap = await _db.collection('chatRooms').doc(roomId)
        .collection('messages')
        .where('senderId', isNotEqualTo: uid)
        .where('isRead', isEqualTo: false)
        .get();
    final batch = _db.batch();
    for (final doc in snap.docs) {
      batch.update(doc.reference, {'isRead': true});
    }
    await batch.commit();
  }
}
