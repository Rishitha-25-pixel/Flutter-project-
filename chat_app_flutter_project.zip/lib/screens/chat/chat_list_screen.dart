import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../providers/auth_provider.dart';
import '../../providers/chat_provider.dart';
import '../../models/chat_room_model.dart';
import 'new_chat_screen.dart';
import 'chat_room_screen.dart';
import '../profile/profile_screen.dart';

class ChatListScreen extends StatelessWidget {
  const ChatListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final uid = context.read<AuthProvider>().currentUser!.uid;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Chats'),
        actions: [
          IconButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ProfileScreen())), icon: const Icon(Icons.person)),
        ],
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: context.read<ChatProvider>().rooms(uid),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          if (snapshot.data!.docs.isEmpty) return const Center(child: Text('No chats yet. Tap + to start.'));
          return ListView(
            children: snapshot.data!.docs.map((doc) {
              final room = ChatRoom.fromFirestore(doc);
              final title = room.isGroup ? (room.groupName ?? 'Group') :
                  room.members.firstWhere((id) => id != uid, orElse: () => 'Chat');
              return ListTile(
                leading: const CircleAvatar(child: Icon(Icons.person)),
                title: Text(title),
                subtitle: Text(room.lastMessage ?? ''),
                onTap: () => Navigator.push(context, MaterialPageRoute(
                  builder: (_) => ChatRoomScreen(roomId: room.id, title: title),
                )),
              );
            }).toList(),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NewChatScreen())),
        child: const Icon(Icons.add),
      ),
    );
  }
}
