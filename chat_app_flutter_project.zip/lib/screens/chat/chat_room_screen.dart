import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import '../../providers/auth_provider.dart';
import '../../providers/chat_provider.dart';
import '../../models/message_model.dart';

class ChatRoomScreen extends StatefulWidget {
  final String roomId;
  final String title;
  const ChatRoomScreen({super.key, required this.roomId, required this.title});

  @override State<ChatRoomScreen> createState() => _ChatRoomScreenState();
}

class _ChatRoomScreenState extends State<ChatRoomScreen> {
  final controller = TextEditingController();

  void send() {
    final text = controller.text.trim();
    if (text.isEmpty) return;
    final user = context.read<AuthProvider>().currentUser!;
    context.read<ChatProvider>().send(
      roomId: widget.roomId,
      senderId: user.uid,
      senderName: user.displayName ?? 'User',
      text: text,
    );
    controller.clear();
  }

  @override
  Widget build(BuildContext context) {
    final uid = context.read<AuthProvider>().currentUser!.uid;
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: Column(children: [
        Expanded(
          child: StreamBuilder<QuerySnapshot>(
            stream: context.read<ChatProvider>().messages(widget.roomId),
            builder: (context, snapshot) {
              if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
              final messages = snapshot.data!.docs.map(ChatMessage.fromFirestore).toList();
              return ListView.builder(
                padding: const EdgeInsets.all(12),
                itemCount: messages.length,
                itemBuilder: (_, i) {
                  final m = messages[i];
                  final mine = m.senderId == uid;
                  return Align(
                    alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
                    child: Container(
                      margin: const EdgeInsets.symmetric(vertical: 4),
                      padding: const EdgeInsets.all(12),
                      constraints: const BoxConstraints(maxWidth: 300),
                      decoration: BoxDecoration(
                        color: mine ? Theme.of(context).colorScheme.primaryContainer : Theme.of(context).colorScheme.surfaceContainerHighest,
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        if (!mine) Text(m.senderName, style: const TextStyle(fontWeight: FontWeight.bold)),
                        if (m.text.isNotEmpty) Text(m.text),
                        Text(DateFormat('hh:mm a').format(m.timestamp), style: const TextStyle(fontSize: 10)),
                      ]),
                    ),
                  );
                },
              );
            },
          ),
        ),
        SafeArea(
          child: Row(children: [
            Expanded(child: TextField(
              controller: controller,
              onSubmitted: (_) => send(),
              decoration: const InputDecoration(hintText: 'Type a message...', border: OutlineInputBorder()),
            )),
            IconButton(onPressed: send, icon: const Icon(Icons.send)),
          ]),
        ),
      ]),
    );
  }
}
