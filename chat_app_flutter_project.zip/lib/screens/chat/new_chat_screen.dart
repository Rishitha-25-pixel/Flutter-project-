import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../providers/auth_provider.dart';
import '../../providers/chat_provider.dart';
import 'chat_room_screen.dart';

class NewChatScreen extends StatelessWidget {
  const NewChatScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final uid = context.read<AuthProvider>().currentUser!.uid;
    return Scaffold(
      appBar: AppBar(title: const Text('New Chat')),
      body: StreamBuilder<QuerySnapshot>(
        stream: context.read<ChatProvider>().users(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final docs = snapshot.data!.docs.where((d) => d.id != uid).toList();
          return ListView(children: docs.map((doc) {
            final data = doc.data() as Map<String, dynamic>;
            return ListTile(
              leading: const CircleAvatar(child: Icon(Icons.person)),
              title: Text(data['name'] ?? 'User'),
              subtitle: Text(data['email'] ?? ''),
              onTap: () async {
                final room = await context.read<ChatProvider>().createRoom(uid, doc.id);
                if (context.mounted) {
                  Navigator.pushReplacement(context, MaterialPageRoute(
                    builder: (_) => ChatRoomScreen(roomId: room, title: data['name'] ?? 'Chat'),
                  ));
                }
              },
            );
          }).toList());
        },
      ),
    );
  }
}
